<?php
session_start();

// Redirect if not admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}

// Include database connection
require_once 'includes/db.php';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        try {
            switch ($_POST['action']) {
                case 'add_user':
                    // Validate input
                    $name = trim($_POST['name']);
                    $email = trim($_POST['email']);
                    $role = $_POST['role'];
                    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    
                    // Check if email already exists
                    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
                    $stmt->execute([$email]);
                    if ($stmt->fetch()) {
                        $_SESSION['error_message'] = "Email already exists!";
                        header('Location: manage_users.php');
                        exit();
                    }
                    
                    // Add new user
                    $stmt = $conn->prepare("INSERT INTO users (name, email, role, password) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$name, $email, $role, $password]);
                    
                    $_SESSION['success_message'] = "User added successfully!";
                    break;
                    
                case 'edit_user':
                    // Edit existing user
                    $user_id = $_POST['user_id'];
                    $name = trim($_POST['name']);
                    $email = trim($_POST['email']);
                    $role = $_POST['role'];
                    
                    // Check if email exists for another user
                    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                    $stmt->execute([$email, $user_id]);
                    if ($stmt->fetch()) {
                        $_SESSION['error_message'] = "Email already exists for another user!";
                        header('Location: manage_users.php');
                        exit();
                    }
                    
                    $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?");
                    $stmt->execute([$name, $email, $role, $user_id]);
                    
                    $_SESSION['success_message'] = "User updated successfully!";
                    break;
                    
                case 'delete_user':
                    // Check if user has leave applications
                    $user_id = $_POST['user_id'];
                    
                    $stmt = $conn->prepare("SELECT COUNT(*) FROM leave_applications WHERE user_id = ?");
                    $stmt->execute([$user_id]);
                    $leave_count = $stmt->fetchColumn();
                    
                    if ($leave_count > 0) {
                        $_SESSION['error_message'] = "Cannot delete user with existing leave applications!";
                        header('Location: manage_users.php');
                        exit();
                    }
                    
                    // Delete user
                    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    
                    $_SESSION['success_message'] = "User deleted successfully!";
                    break;
                    
                case 'reset_password':
                    // Reset password
                    $user_id = $_POST['user_id'];
                    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    
                    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt->execute([$password, $user_id]);
                    
                    $_SESSION['success_message'] = "Password reset successfully!";
                    break;
            }
            
            header('Location: manage_users.php');
            exit();
            
        } catch(PDOException $e) {
            $_SESSION['error_message'] = "Database error: " . $e->getMessage();
            header('Location: manage_users.php');
            exit();
        }
    }
}

// Fetch all users with search and filter
$search = $_GET['search'] ?? '';
$role_filter = $_GET['role'] ?? '';

$query = "SELECT u.*, 
          (SELECT COUNT(*) FROM leave_applications la WHERE la.user_id = u.id) as leave_count
          FROM users u WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (u.name LIKE ? OR u.email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($role_filter)) {
    $query .= " AND u.role = ?";
    $params[] = $role_filter;
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Count total records
$count_query = "SELECT COUNT(*) FROM users u WHERE 1=1" . 
               (!empty($search) ? " AND (u.name LIKE ? OR u.email LIKE ?)" : "") .
               (!empty($role_filter) ? " AND u.role = ?" : "");
               
$count_params = [];
if (!empty($search)) {
    $count_params[] = "%$search%";
    $count_params[] = "%$search%";
}
if (!empty($role_filter)) {
    $count_params[] = $role_filter;
}

$stmt = $conn->prepare($count_query);
$stmt->execute($count_params);
$total_records = $stmt->fetchColumn();
$total_pages = ceil($total_records / $limit);

// Fetch users with pagination
$query .= " ORDER BY u.name ASC LIMIT $limit OFFSET $offset";
$stmt = $conn->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Leave Management System</title>
    <link rel="stylesheet" href="./admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-user-shield"></i> Admin Panel</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="admin.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li class="active"><a href="manage_users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                    <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <img src="https://via.placeholder.com/40" alt="Admin Avatar">
                    <div>
                        <span class="username"><?php echo $_SESSION['name'] ?? 'Admin'; ?></span>
                        <span class="role">Administrator</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <header class="main-header">
                <h1><i class="fas fa-users-cog"></i> User Management</h1>
                <div class="header-actions">
                    <button id="add-user-btn" class="btn-primary">
                        <i class="fas fa-plus"></i> Add User
                    </button>
                </div>
            </header>

            <!-- Status Messages -->
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger">
                    <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                </div>
            <?php endif; ?>

            <!-- Search and Filter Form -->
            <div class="card filter-card">
                <div class="card-header">
                    <h3><i class="fas fa-filter"></i> Filter Users</h3>
                </div>
                <div class="card-body">
                    <form action="manage_users.php" method="GET" class="search-filter-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="search"><i class="fas fa-search"></i> Search</label>
                                <input type="text" id="search" name="search" placeholder="Name or Email" value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="form-group">
                                <label for="role"><i class="fas fa-user-tag"></i> Role</label>
                                <select id="role" name="role">
                                    <option value="">All Roles</option>
                                    <option value="admin" <?php echo $role_filter == 'admin' ? 'selected' : ''; ?>>Admin</option>
                                    <option value="teacher" <?php echo $role_filter == 'teacher' ? 'selected' : ''; ?>>Teacher</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn-primary"><i class="fas fa-filter"></i> Apply Filters</button>
                            <a href="manage_users.php" class="btn-secondary"><i class="fas fa-broom"></i> Reset</a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Users Table -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> User List</h3>
                    <div class="table-actions">
                        <span>Showing <?php echo count($users); ?> of <?php echo $total_records; ?> users</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Leave Apps</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo $user['id']; ?></td>
                                        <td>
                                            <div class="user-cell">
                                                <div class="user-avatar"><?php echo substr($user['name'], 0, 1); ?></div>
                                                <div>
                                                    <div class="user-name"><?php echo htmlspecialchars($user['name']); ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td>
                                            <span class="role-badge <?php echo $user['role']; ?>">
                                                <?php echo ucfirst($user['role']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo $user['leave_count']; ?></td>
                                        <td>
                                            <div class="action-buttons">
                                                <button class="btn-action btn-edit" data-user-id="<?php echo $user['id']; ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn-action btn-reset-password" data-user-id="<?php echo $user['id']; ?>">
                                                    <i class="fas fa-key"></i>
                                                </button>
                                                <button class="btn-action btn-delete" data-user-id="<?php echo $user['id']; ?>" 
                                                    <?php echo $user['leave_count'] > 0 ? 'disabled title="User has leave applications"' : ''; ?>>
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="manage_users.php?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo urlencode($role_filter); ?>" class="page-nav">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        <?php endif; ?>
                        
                        <?php 
                        $start_page = max(1, $page - 2);
                        $end_page = min($total_pages, $start_page + 4);
                        
                        if ($start_page > 1): ?>
                            <a href="manage_users.php?page=1&search=<?php echo urlencode($search); ?>&role=<?php echo urlencode($role_filter); ?>">1</a>
                            <?php if ($start_page > 2): ?>
                                <span class="page-dots">...</span>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                            <a href="manage_users.php?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo urlencode($role_filter); ?>"
                               class="<?php echo $page == $i ? 'active' : ''; ?>">
                                <?php echo $i; ?>
                            </a>
                        <?php endfor; ?>
                        
                        <?php if ($end_page < $total_pages): ?>
                            <?php if ($end_page < $total_pages - 1): ?>
                                <span class="page-dots">...</span>
                            <?php endif; ?>
                            <a href="manage_users.php?page=<?php echo $total_pages; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo urlencode($role_filter); ?>">
                                <?php echo $total_pages; ?>
                            </a>
                        <?php endif; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="manage_users.php?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo urlencode($role_filter); ?>" class="page-nav">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add/Edit User Modal -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Add New User</h3>
                <button class="close-modal">&times;</button>
            </div>
            <form id="userForm" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" id="formAction" value="add_user">
                    <input type="hidden" name="user_id" id="userId">
                    
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select id="roleSelect" name="role" required>
                            <option value="teacher">Teacher</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="passwordGroup">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                        <small class="form-text">Minimum 8 characters</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-secondary close-modal">Cancel</button>
                    <button type="submit" class="btn-primary">Save User</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Reset Password Modal -->
    <div id="passwordModal" class="modal">
        <div class="modal-content small">
            <div class="modal-header">
                <h3>Reset Password</h3>
                <button class="close-modal">&times;</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="user_id" id="resetUserId">
                    
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <input type="password" id="new_password" name="password" required>
                        <small class="form-text">Minimum 8 characters</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-secondary close-modal">Cancel</button>
                    <button type="submit" class="btn-primary">Reset Password</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content small">
            <div class="modal-header">
                <h3>Confirm Deletion</h3>
                <button class="close-modal">&times;</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="delete_user">
                    <input type="hidden" name="user_id" id="deleteUserId">
                    <p>Are you sure you want to delete this user? This action cannot be undone.</p>
                    <p class="text-warning"><strong>Warning:</strong> If this user has leave applications, deletion will be blocked.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-secondary close-modal">Cancel</button>
                    <button type="submit" class="btn-danger">Delete User</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Modal elements
            const modals = document.querySelectorAll('.modal');
            const closeButtons = document.querySelectorAll('.close-modal');
            
            // Add User Button
            document.getElementById('add-user-btn').addEventListener('click', function() {
                document.getElementById('modalTitle').textContent = 'Add New User';
                document.getElementById('formAction').value = 'add_user';
                document.getElementById('userId').value = '';
                document.getElementById('userForm').reset();
                document.getElementById('passwordGroup').style.display = 'block';
                document.getElementById('userModal').style.display = 'block';
            });
            
            // Edit User Buttons
            document.querySelectorAll('.btn-edit').forEach(btn => {
                btn.addEventListener('click', function() {
                    const userId = this.getAttribute('data-user-id');
                    
                    fetch(`get_user.php?id=${userId}`)
                        .then(response => response.json())
                        .then(user => {
                            document.getElementById('modalTitle').textContent = 'Edit User';
                            document.getElementById('formAction').value = 'edit_user';
                            document.getElementById('userId').value = user.id;
                            document.getElementById('name').value = user.name;
                            document.getElementById('email').value = user.email;
                            document.getElementById('roleSelect').value = user.role;
                            document.getElementById('passwordGroup').style.display = 'none';
                            document.getElementById('userModal').style.display = 'block';
                        });
                });
            });
            
            // Reset Password Buttons
            document.querySelectorAll('.btn-reset-password').forEach(btn => {
                btn.addEventListener('click', function() {
                    const userId = this.getAttribute('data-user-id');
                    document.getElementById('resetUserId').value = userId;
                    document.getElementById('passwordModal').style.display = 'block';
                });
            });
            
            // Delete Buttons
            document.querySelectorAll('.btn-delete').forEach(btn => {
                btn.addEventListener('click', function() {
                    if (!this.disabled) {
                        const userId = this.getAttribute('data-user-id');
                        document.getElementById('deleteUserId').value = userId;
                        document.getElementById('deleteModal').style.display = 'block';
                    }
                });
            });
            
            // Close modals
            closeButtons.forEach(btn => {
                btn.addEventListener('click', function() {
                    modals.forEach(modal => {
                        modal.style.display = 'none';
                    });
                });
            });
            
            // Close when clicking outside modal
            window.addEventListener('click', function(event) {
                modals.forEach(modal => {
                    if (event.target === modal) {
                        modal.style.display = 'none';
                    }
                });
            });
            
            // Form validation
            const passwordInputs = document.querySelectorAll('input[type="password"]');
            passwordInputs.forEach(input => {
                input.addEventListener('input', function() {
                    if (this.value.length > 0 && this.value.length < 8) {
                        this.style.borderColor = '#dc3545';
                        if (this.nextElementSibling) {
                            this.nextElementSibling.style.color = '#dc3545';
                        }
                    } else {
                        this.style.borderColor = '';
                        if (this.nextElementSibling) {
                            this.nextElementSibling.style.color = '';
                        }
                    }
                });
            });
            
            // Email validation
            const emailInput = document.getElementById('email');
            if (emailInput) {
                emailInput.addEventListener('blur', function() {
                    if (!this.value.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                        this.style.borderColor = '#dc3545';
                    } else {
                        this.style.borderColor = '';
                    }
                });
            }
        });
    </script>
</body>
</html>
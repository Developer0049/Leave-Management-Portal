<?php
session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once 'includes/db.php';

// Fetch user details
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Fetch all leave applications for the user
$stmt = $conn->prepare("
    SELECT * FROM leave_applications 
    WHERE user_id = ? 
    ORDER BY created_at DESC
");
$stmt->execute([$user_id]);
$leave_history = $stmt->fetchAll();


        // Fetch unread notifications
        $stmt = $conn->prepare("
        SELECT * FROM notifications 
        WHERE user_id = ? AND is_read = 0 
        ORDER BY created_at DESC 
        LIMIT 10
        ");
        
        $notifications = $stmt->fetchAll();
        $notification_count = count($notifications);

        
        
// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate inputs
    if (empty($name) || empty($email)) {
        $error = "Name and email are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (!empty($password) && $password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Update user details
        if (empty($password)) {
            $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
            $stmt->execute([$name, $email, $user_id]);
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?");
            $stmt->execute([$name, $email, $hashed_password, $user_id]);
        }

        // Refresh user data
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        $success = "Profile updated successfully!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="./css/main.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-calendar-alt"></i> Leave Portal</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="main.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="#apply-leave"><i class="fas fa-file-signature"></i> Apply for Leave</a></li>
                    <li><a href="leave_history.php"><i class="fas fa-history"></i> Leave History</a></li>
                    <li class="active"><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($user['name'], 0, 1)); ?></div>
                    <div>
                        <span class="username"><?php echo htmlspecialchars($user['name']); ?></span>
                        <span class="role"><?php echo ucfirst($user['role']); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <header class="main-header">
                <h1><i class="fas fa-user"></i> My Profile</h1>
                <div class="header-actions">
    <div class="notifications-dropdown">
        <button id="notifications-btn" class="btn-icon">
            <i class="fas fa-bell"></i>
            <?php if ($notification_count > 0): ?>
                <span class="badge"><?php echo $notification_count; ?></span>
            <?php endif; ?>
        </button>
        <div class="notifications-menu">
            <div class="notifications-header">
                <h4>Notifications</h4>
                <?php if ($notification_count > 0): ?>
                    <button id="mark-all-read" class="btn-link">Mark all as read</button>
                <?php endif; ?>
            </div>
            <div class="notifications-list">
                <?php if (empty($notifications)): ?>
                    <div class="notification-item empty">No new notifications</div>
                <?php else: ?>
                    <?php foreach ($notifications as $notification): ?>
                        <div class="notification-item <?php echo !$notification['is_read'] ? 'unread' : ''; ?>" data-notification-id="<?php echo $notification['id']; ?>">
                            <div class="notification-icon">
                                <i class="fas <?php 
                                    echo $notification['type'] == 'approval' ? 'fa-check-circle' : 
                                         ($notification['type'] == 'rejection' ? 'fa-times-circle' : 'fa-info-circle'); 
                                ?>"></i>
                            </div>
                            <div class="notification-content">
                                <p><?php echo htmlspecialchars($notification['message']); ?></p>
                                <small><?php echo date('M d, Y h:i A', strtotime($notification['created_at'])); ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="notifications-footer">
                <a href="notifications.php" class="btn-link">View all notifications</a>
            </div>
        </div>
    </div>
</div>
            </header>

            <!-- Profile Update Form -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-user-edit"></i> Update Profile</h3>
                </div>
                <div class="card-body">
                    <?php if (isset($error)): ?>
                        <div class="alert alert-error"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    <form id="profileForm" method="POST">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="password">New Password</label>
                                <input type="password" id="password" name="password">
                                <small class="form-text">Leave blank to keep current password.</small>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password">
                            </div>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn-primary">
                                <i class="fas fa-save"></i> Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Leave History Table -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-history"></i> Leave History</h3>
                </div>
                <div class="card-body">
                    <?php if (empty($leave_history)): ?>
                        <p class="no-data">No leave applications found.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Leave Type</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Substitute Allotted</th>
                                        <th>Substitute Details</th>
                                        <th>Created At</th>
                                        <th>Is Cancelled</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($leave_history as $leave): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($leave['leave_type']); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($leave['leave_start_date'])); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($leave['leave_end_date'])); ?></td>
                                            <td>
                                                <span class="status-badge <?php echo strtolower(str_replace(' ', '-', $leave['status'])); ?>">
                                                    <?php echo $leave['status']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo $leave['substitute_allotted'] ? 'Yes' : 'No'; ?></td>
                                            <td><?php echo htmlspecialchars($leave['substitute_details'] ?? 'N/A'); ?></td>
                                            <td><?php echo date('M d, Y H:i', strtotime($leave['created_at'])); ?></td>
                                            <td><?php echo $leave['is_cancelled'] ? 'Yes' : 'No'; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Password validation
            document.getElementById('profileForm').addEventListener('submit', function(e) {
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirm_password').value;

                if (password !== confirmPassword) {
                    alert('Passwords do not match.');
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
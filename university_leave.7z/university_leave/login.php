<?php
session_start();
require_once 'includes/db.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['role'] == 'admin' ? 'admin.php' : 'main.php'));
    exit();
}

// Initialize variables
$error = '';
$email = '';
$login_attempts = $_SESSION['login_attempts'] ?? 0;
$last_attempt = $_SESSION['last_attempt'] ?? 0;
$lockout_time = 30; // 5 minutes in seconds

// Check if account is temporarily locked
if ($login_attempts >= 5 && (time() - $last_attempt) < $lockout_time) {
    $remaining_time = $lockout_time - (time() - $last_attempt);
    $error = "Too many failed attempts. Please try again in " . ceil($remaining_time/60) . " minutes.";
    $disable_form = true;
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    // Basic validation
    if (empty($email) || empty($password)) {
        $error = "Please enter both email and password";
    } else {
        try {
            // Fetch user with prepared statement
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                // Check if account is locked
                if ($user['is_locked'] && strtotime($user['lockout_until']) > time()) {
                    $error = "Account locked. Please try again later or contact support.";
                } elseif (password_verify($password, $user['password'])) {
                    // Successful login
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['name'] = $user['name'];
                    $_SESSION['login_time'] = time();
                    
                    // Reset login attempts
                    $_SESSION['login_attempts'] = 0;
                    
                    // Remember me functionality
                    if ($remember) {
                        $token = bin2hex(random_bytes(32));
                        $expiry = time() + 60*60*24*30; // 30 days
                        
                        setcookie('remember_token', $token, $expiry, '/');
                        setcookie('remember_user', $user['id'], $expiry, '/');
                        
                        // Store in database
                        $stmt = $conn->prepare("UPDATE users SET remember_token = ?, token_expiry = ? WHERE id = ?");
                        $stmt->execute([$token, date('Y-m-d H:i:s', $expiry), $user['id']]);
                    }
                    
                    // Update last login
                    $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $stmt->execute([$user['id']]);
                    
                    // Redirect based on role
                    header('Location: ' . ($user['role'] == 'admin' ? 'admin.php' : 'main.php'));
                    exit();
                } else {
                    // Failed attempt
                    $error = "Invalid email or password";
                    $_SESSION['login_attempts'] = $login_attempts + 1;
                    $_SESSION['last_attempt'] = time();
                    
                    // Lock account after 5 failed attempts
                    if ($_SESSION['login_attempts'] >= 5) {
                        $lockout_until = date('Y-m-d H:i:s', time() + $lockout_time);
                        $stmt = $conn->prepare("UPDATE users SET is_locked = 1, lockout_until = ? WHERE email = ?");
                        $stmt->execute([$lockout_until, $email]);
                    }
                }
            } else {
                $error = "Invalid email or password";
                $_SESSION['login_attempts'] = $login_attempts + 1;
                $_SESSION['last_attempt'] = time();
            }
        } catch(PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            $error = "A system error occurred. Please try again later.";
        }
    }
}

// Check for "remember me" cookie
if (empty($_SESSION['user_id']) && isset($_COOKIE['remember_token']) && isset($_COOKIE['remember_user'])) {
    try {
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND remember_token = ? AND token_expiry > NOW()");
        $stmt->execute([$_COOKIE['remember_user'], $_COOKIE['remember_token']]);
        $user = $stmt->fetch();
        
        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['login_time'] = time();
            
            // Update last login
            $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $stmt->execute([$user['id']]);
            
            header('Location: ' . ($user['role'] == 'admin' ? 'admin.php' : 'main.php'));
            exit();
        }
    } catch(PDOException $e) {
        error_log("Remember me error: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Presidency University Leave Portal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="./css//login.css">
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
</head>
<body>
    <div id="particles-js"></div>
    
    <div class="login-container">
        <div class="logo-container">
            <!-- <img src="logo.png" alt="University Logo" class="logo"> -->
            <div class="logo-text">
                <h1>UNIVERSITY</h1>
                <h2>LEAVE APPLICATION PORTAL</h2>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>Login to Your Account</h2>
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <form action="login.php" method="POST" class="login-form" <?php echo isset($disable_form) ? 'data-locked="true"' : ''; ?>>
                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" 
                           required <?php echo isset($disable_form) ? 'disabled' : ''; ?>>
                </div>
                
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Password</label>
                    <div class="password-input">
                        <input type="password" id="password" name="password" required 
                               <?php echo isset($disable_form) ? 'disabled' : ''; ?>>
                        <button type="button" class="toggle-password">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <a href="forgot_password.php" class="forgot-password">Forgot Password?</a>
                </div>
                
                <div class="form-options">
                    <label class="remember-me">
                        <input type="checkbox" name="remember" <?php echo isset($disable_form) ? 'disabled' : ''; ?>>
                        <span>Remember me</span>
                    </label>
                </div>
                
                <button type="submit" class="btn-login" <?php echo isset($disable_form) ? 'disabled' : ''; ?>>
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
                
                <div class="divider">
                    <span>or</span>
                </div>
                
                <div class="social-login">
                    <p>Login with:</p>
                    <div class="social-buttons">
                        <button type="button" class="btn-google">
                            <i class="fab fa-google"></i> Google
                        </button>
                        <button type="button" class="btn-microsoft">
                            <i class="fab fa-microsoft"></i> Microsoft
                        </button>
                    </div>
                </div>
            </form>
            
            <div class="card-footer">
                Don't have an account? <a href="register.php">Register here</a>.
            </div>
        </div>
    </div>
    
    <button id="theme-toggle" class="floating-btn">
        <i class="fas fa-moon"></i>
    </button>
    
    <script>
        // Initialize particles.js
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof particlesJS !== 'undefined') {
                particlesJS.load('particles-js', 'assets/particles.json');
            }
            
            // Toggle password visibility
            const togglePassword = document.querySelector('.toggle-password');
            const password = document.getElementById('password');
            
            if (togglePassword && password) {
                togglePassword.addEventListener('click', function() {
                    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                    password.setAttribute('type', type);
                    this.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
                });
            }
            
            // Theme toggle
            const themeToggle = document.getElementById('theme-toggle');
            if (themeToggle) {
                themeToggle.addEventListener('click', function() {
                    document.body.classList.toggle('dark-theme');
                    const icon = this.querySelector('i');
                    if (document.body.classList.contains('dark-theme')) {
                        icon.classList.replace('fa-moon', 'fa-sun');
                        localStorage.setItem('theme', 'dark');
                    } else {
                        icon.classList.replace('fa-sun', 'fa-moon');
                        localStorage.setItem('theme', 'light');
                    }
                });
                
                // Check for saved theme preference
                if (localStorage.getItem('theme') === 'dark') {
                    document.body.classList.add('dark-theme');
                    themeToggle.querySelector('i').classList.replace('fa-moon', 'fa-sun');
                }
            }
            
            // Form submission handling
            const form = document.querySelector('.login-form');
            if (form && form.dataset.locked === 'true') {
                const inputs = form.querySelectorAll('input, button');
                inputs.forEach(input => input.disabled = true);
            }
        });
    </script>
</body>
</html>
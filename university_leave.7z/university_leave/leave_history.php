<?php
session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once 'includes/db.php';

// Fetch user details
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

        // Fetch unread notifications
        $stmt = $conn->prepare("
        SELECT * FROM notifications 
        WHERE user_id = ? AND is_read = 0 
        ORDER BY created_at DESC 
        LIMIT 10
        ");
        
        $notifications = $stmt->fetchAll();
        $notification_count = count($notifications);
        

// Fetch all leave applications for the user
$stmt = $conn->prepare("
    SELECT * FROM leave_applications 
    WHERE user_id = ? 
    ORDER BY created_at DESC
");
$stmt->execute([$user_id]);
$leave_history = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave History</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="./css/main.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-calendar-alt"></i> Leave Portal</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="main.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="#apply-leave"><i class="fas fa-file-signature"></i> Apply for Leave</a></li>
                    <li class="active"><a href="leave_history.php"><i class="fas fa-history"></i> Leave History</a></li>
                    <li><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($user['name'], 0, 1)); ?></div>
                    <div>
                        <span class="username"><?php echo htmlspecialchars($user['name']); ?></span>
                        <span class="role"><?php echo ucfirst($user['role']); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <header class="main-header">
                <h1><i class="fas fa-history"></i> Leave History</h1>
                <div class="header-actions">
    <div class="notifications-dropdown">
        <button id="notifications-btn" class="btn-icon">
            <i class="fas fa-bell"></i>
            <?php if ($notification_count > 0): ?>
                <span class="badge"><?php echo $notification_count; ?></span>
            <?php endif; ?>
        </button>
        <div class="notifications-menu">
            <div class="notifications-header">
                <h4>Notifications</h4>
                <?php if ($notification_count > 0): ?>
                    <button id="mark-all-read" class="btn-link">Mark all as read</button>
                <?php endif; ?>
            </div>
            <div class="notifications-list">
                <?php if (empty($notifications)): ?>
                    <div class="notification-item empty">No new notifications</div>
                <?php else: ?>
                    <?php foreach ($notifications as $notification): ?>
                        <div class="notification-item <?php echo !$notification['is_read'] ? 'unread' : ''; ?>" data-notification-id="<?php echo $notification['id']; ?>">
                            <div class="notification-icon">
                                <i class="fas <?php 
                                    echo $notification['type'] == 'approval' ? 'fa-check-circle' : 
                                         ($notification['type'] == 'rejection' ? 'fa-times-circle' : 'fa-info-circle'); 
                                ?>"></i>
                            </div>
                            <div class="notification-content">
                                <p><?php echo htmlspecialchars($notification['message']); ?></p>
                                <small><?php echo date('M d, Y h:i A', strtotime($notification['created_at'])); ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="notifications-footer">
                <a href="notifications.php" class="btn-link">View all notifications</a>
            </div>
        </div>
    </div>
</div>
            </header>

            <!-- Leave History Table -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-history"></i> All Leave Applications</h3>
                </div>
                <div class="card-body">
                    <?php if (empty($leave_history)): ?>
                        <p class="no-data">No leave applications found.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Leave Type</th>
                                        <th>Dates</th>
                                        <th>Days</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($leave_history as $leave): ?>
                                        <?php
                                        $start = new DateTime($leave['leave_start_date']);
                                        $end = new DateTime($leave['leave_end_date']);
                                        $interval = $start->diff($end);
                                        $total_days = $interval->days + 1;
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($leave['leave_type']); ?></td>
                                            <td>
                                                <?php echo date('M d', strtotime($leave['leave_start_date'])); ?> - 
                                                <?php echo date('M d, Y', strtotime($leave['leave_end_date'])); ?>
                                            </td>
                                            <td><?php echo $total_days; ?></td>
                                            <td>
                                                <span class="status-badge <?php echo strtolower(str_replace(' ', '-', $leave['status'])); ?>">
                                                    <?php echo $leave['status']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn-action btn-view" data-leave-id="<?php echo $leave['id']; ?>">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <?php if ($leave['status'] == 'Pending'): ?>
                                                    <button class="btn-action btn-cancel" data-leave-id="<?php echo $leave['id']; ?>">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Leave Details Modal -->
    <div id="leaveModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Leave Application Details</h3>
                <button class="close-modal">&times;</button>
            </div>
            <div class="modal-body" id="modalContent">
                <!-- Content loaded via AJAX -->
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // View leave details
            document.querySelectorAll('.btn-view').forEach(btn => {
                btn.addEventListener('click', function() {
                    const leaveId = this.getAttribute('data-leave-id');
                    fetch(`get_leave_details.php?id=${leaveId}`)
                        .then(response => response.text())
                        .then(data => {
                            document.getElementById('modalContent').innerHTML = data;
                            document.getElementById('leaveModal').style.display = 'block';
                        });
                });
            });

            // Cancel leave application
            document.querySelectorAll('.btn-cancel').forEach(btn => {
                btn.addEventListener('click', function() {
                    const leaveId = this.getAttribute('data-leave-id');
                    if (confirm('Are you sure you want to cancel this leave application?')) {
                        fetch(`cancel_leave.php?id=${leaveId}`)
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    location.reload();
                                } else {
                                    alert(data.error || 'Failed to cancel leave');
                                }
                            });
                    }
                });
            });

            // Close modal
            document.querySelectorAll('.close-modal').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.getElementById('leaveModal').style.display = 'none';
                });
            });

            // Close modal when clicking outside
            window.addEventListener('click', function(e) {
                if (e.target === document.getElementById('leaveModal')) {
                    document.getElementById('leaveModal').style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
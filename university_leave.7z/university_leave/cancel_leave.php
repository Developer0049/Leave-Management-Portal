<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 403 Forbidden');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $leave_id = $_POST['id'];
    $user_id = $_SESSION['user_id'];
    
    try {
        // Check if leave belongs to user and is pending
        $stmt = $conn->prepare("SELECT id FROM leave_applications WHERE id = ? AND user_id = ? AND status = 'Pending'");
        $stmt->execute([$leave_id, $user_id]);
        
        if ($stmt->fetch()) {
            // Delete the leave application
            $stmt = $conn->prepare("DELETE FROM leave_applications WHERE id = ?");
            $stmt->execute([$leave_id]);
            
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Leave not found or cannot be cancelled']);
        }
    } catch(PDOException $e) {
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(['success' => false, 'error' => 'Database error']);
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
?>
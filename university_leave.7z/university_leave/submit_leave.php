<?php
session_start();

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $teacher_id = $_POST['teacher_id'];
    $leave_type = $_POST['leave_type'];
    $leave_start_date = $_POST['leave_start_date'];
    $leave_end_date = $_POST['leave_end_date'];
    $description = $_POST['description'];
    $substitute_allotted = $_POST['substitute_allotted'];
    $substitute_details = $_POST['substitute_details'] ?? null;

    // Insert leave application into the database
    $stmt = $conn->prepare("INSERT INTO leave_applications (user_id, teacher_id, name, email, leave_type, leave_start_date, leave_end_date, description, substitute_allotted, substitute_details, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', NOW())");
    $stmt->execute([$user_id, $teacher_id, $name, $email, $leave_type, $leave_start_date, $leave_end_date, $description, $substitute_allotted, $substitute_details]);

    // Redirect to the main page
    header('Location: main.php');
    exit();
}
?>
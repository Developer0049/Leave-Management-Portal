<?php
session_start();

// Redirect if not admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}

require_once 'includes/db.php';

// Get report parameters
$report_type = $_GET['type'] ?? 'monthly';
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$department = $_GET['department'] ?? '';

// Base data for charts
$monthly_stats = [];
$leave_types = [];
$department_stats = [];

try {
    // Monthly leave stats
    $query = "SELECT 
                MONTH(created_at) as month, 
                status, 
                COUNT(*) as count 
              FROM leave_applications 
              WHERE YEAR(created_at) = ? 
              GROUP BY MONTH(created_at), status";
    $stmt = $conn->prepare($query);
    $stmt->execute([$year]);
    $monthly_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Process monthly data
    foreach ($monthly_data as $row) {
        $month_name = date('F', mktime(0, 0, 0, $row['month'], 1));
        if (!isset($monthly_stats[$month_name])) {
            $monthly_stats[$month_name] = [
                'Pending' => 0,
                'Approved' => 0,
                'Not Approved' => 0
            ];
        }
        $monthly_stats[$month_name][$row['status']] = $row['count'];
    }

    // Leave type distribution
    $query = "SELECT leave_type, COUNT(*) as count FROM leave_applications GROUP BY leave_type";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $leave_types = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Department stats (if you add departments later)
    $query = "SELECT 
                d.name as department,
                COUNT(la.id) as total,
                SUM(CASE WHEN la.status = 'Approved' THEN 1 ELSE 0 END) as approved
              FROM leave_applications la
              JOIN users u ON la.user_id = u.id
              LEFT JOIN departments d ON u.department_id = d.id
              GROUP BY d.name";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $department_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch(PDOException $e) {
    $_SESSION['error_message'] = "Error generating reports: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports | Leave Management System</title>
    <link rel="stylesheet" href="./admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-user-shield"></i> Admin Panel</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="admin.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="manage_users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                    <li class="active"><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <img src="https://via.placeholder.com/40" alt="Admin Avatar">
                    <div>
                        <span class="username"><?php echo $_SESSION['name'] ?? 'Admin'; ?></span>
                        <span class="role">Administrator</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <header class="main-header">
                <h1><i class="fas fa-chart-pie"></i> System Reports</h1>
                <div class="header-actions">
                    <button id="export-reports" class="btn-primary">
                        <i class="fas fa-file-export"></i> Export Data
                    </button>
                </div>
            </header>

            <!-- Report Filters -->
            <div class="card filter-card">
                <div class="card-header">
                    <h3><i class="fas fa-filter"></i> Report Filters</h3>
                </div>
                <div class="card-body">
                    <form action="reports.php" method="GET" class="search-filter-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="type"><i class="fas fa-chart-line"></i> Report Type</label>
                                <select id="type" name="type">
                                    <option value="monthly" <?= $report_type == 'monthly' ? 'selected' : '' ?>>Monthly Overview</option>
                                    <option value="leave_types" <?= $report_type == 'leave_types' ? 'selected' : '' ?>>Leave Type Analysis</option>
                                    <option value="department" <?= $report_type == 'department' ? 'selected' : '' ?>>Department Analysis</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="year"><i class="fas fa-calendar-alt"></i> Year</label>
                                <select id="year" name="year">
                                    <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                                        <option value="<?= $y ?>" <?= $year == $y ? 'selected' : '' ?>><?= $y ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn-primary"><i class="fas fa-filter"></i> Apply Filters</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Monthly Report -->
            <?php if ($report_type == 'monthly'): ?>
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-calendar"></i> Monthly Leave Statistics for <?= $year ?></h3>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="monthlyChart"></canvas>
                    </div>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Month</th>
                                    <th>Pending</th>
                                    <th>Approved</th>
                                    <th>Not Approved</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($monthly_stats as $month => $stats): ?>
                                <tr>
                                    <td><?= $month ?></td>
                                    <td><?= $stats['Pending'] ?></td>
                                    <td><?= $stats['Approved'] ?></td>
                                    <td><?= $stats['Not Approved'] ?></td>
                                    <td><?= array_sum($stats) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Leave Type Report -->
            <?php if ($report_type == 'leave_types'): ?>
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-tags"></i> Leave Type Distribution</h3>
                </div>
                <div class="card-body">
                    <div class="chart-container" style="height: 400px;">
                        <canvas id="leaveTypeChart"></canvas>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Department Report -->
            <?php if ($report_type == 'department'): ?>
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-building"></i> Department Leave Statistics</h3>
                </div>
                <div class="card-body">
                    <div class="chart-container" style="height: 400px;">
                        <canvas id="departmentChart"></canvas>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Monthly Chart
            <?php if ($report_type == 'monthly'): ?>
            const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
            new Chart(monthlyCtx, {
                type: 'bar',
                data: {
                    labels: <?= json_encode(array_keys($monthly_stats)) ?>,
                    datasets: [
                        {
                            label: 'Pending',
                            data: <?= json_encode(array_column($monthly_stats, 'Pending')) ?>,
                            backgroundColor: '#FFC107'
                        },
                        {
                            label: 'Approved',
                            data: <?= json_encode(array_column($monthly_stats, 'Approved')) ?>,
                            backgroundColor: '#28A745'
                        },
                        {
                            label: 'Not Approved',
                            data: <?= json_encode(array_column($monthly_stats, 'Not Approved')) ?>,
                            backgroundColor: '#DC3545'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        x: { stacked: true },
                        y: { stacked: true, beginAtZero: true }
                    }
                }
            });
            <?php endif; ?>

            // Leave Type Chart
            <?php if ($report_type == 'leave_types'): ?>
            const leaveTypeCtx = document.getElementById('leaveTypeChart').getContext('2d');
            new Chart(leaveTypeCtx, {
                type: 'pie',
                data: {
                    labels: <?= json_encode(array_column($leave_types, 'leave_type')) ?>,
                    datasets: [{
                        data: <?= json_encode(array_column($leave_types, 'count')) ?>,
                        backgroundColor: [
                            '#3498db', '#2ecc71', '#e74c3c', '#f39c12', 
                            '#9b59b6', '#1abc9c', '#d35400', '#34495e'
                        ]
                    }]
                }
            });
            <?php endif; ?>

            // Department Chart
            <?php if ($report_type == 'department' && !empty($department_stats)): ?>
            const deptCtx = document.getElementById('departmentChart').getContext('2d');
            new Chart(deptCtx, {
                type: 'bar',
                data: {
                    labels: <?= json_encode(array_column($department_stats, 'department')) ?>,
                    datasets: [
                        {
                            label: 'Total Applications',
                            data: <?= json_encode(array_column($department_stats, 'total')) ?>,
                            backgroundColor: '#3498db'
                        },
                        {
                            label: 'Approved',
                            data: <?= json_encode(array_column($department_stats, 'approved')) ?>,
                            backgroundColor: '#2ecc71'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: { beginAtZero: true }
                    }
                }
            });
            <?php endif; ?>
        });
    </script>
</body>
</html>
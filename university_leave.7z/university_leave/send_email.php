<?php
session_start();

// Redirect to login if the user is not logged in or is not an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}

include 'includes/db.php';
include 'includes/mail_config.php';
require 'vendor/autoload.php'; // Ensure PHPMailer is properly included

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Check if leave ID is provided
if (!isset($_POST['leave_id'])) {
    die("Leave ID not provided.");
}

$leave_id = $_POST['leave_id'];
$custom_message = $_POST['custom_message'] ?? '';

// Fetch leave application details
$stmt = $conn->prepare("SELECT * FROM leave_applications WHERE id = ?");
$stmt->execute([$leave_id]);
$leave = $stmt->fetch();

if (!$leave) {
    die("Leave application not found.");
}

// Fetch the applicant's email
$applicant_email = $leave['email'];

// Send email notification
$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';  
    $mail->SMTPAuth = true;
    $mail->Username = 'presidency.timetableteam@gmail.com'; 
    $mail->Password = 'uyvu wxnq xbyj nktu';  
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; 

    $mail->setFrom('presidency.timetableteam@gmail.com', 'University Leave Management'); 
    $mail->addAddress($applicant_email); // Add the applicant's email

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Leave Application Status';
    $mail->Body    = "
        <h3>Leave Application Status</h3>
        <p>Your leave application details are as follows:</p>
        <ul>
            <li><strong>Leave ID:</strong> {$leave['id']}</li>
            <li><strong>Teacher ID:</strong> {$leave['teacher_id']}</li>
            <li><strong>Name:</strong> {$leave['name']}</li>
            <li><strong>Leave Type:</strong> {$leave['leave_type']}</li>
            <li><strong>Start Date:</strong> {$leave['leave_start_date']}</li>
            <li><strong>End Date:</strong> {$leave['leave_end_date']}</li>
            <li><strong>Description:</strong> {$leave['description']}</li>
            <li><strong>Status:</strong>  <span style='color: blue;'>{$leave['status']}</li>
        </ul>
        <p><strong>Message from Admin:</strong> {$custom_message}</p>
        <p>Thank you for using our leave management system.</p>
    ";

    $mail->send();
    $_SESSION['email_sent'] = "Email sent successfully.";
} catch (Exception $e) {
    $_SESSION['email_error'] = "Email could not be sent. Error: {$mail->ErrorInfo}";
}

// Redirect back to the admin page with JavaScript alert
echo "<script>
    alert('" . ($_SESSION['email_sent'] ?? $_SESSION['email_error']) . "');
    window.location.href = 'admin.php';
</script>";
exit();

<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 403 Forbidden');
    exit();
}

if (isset($_GET['id'])) {
    $leave_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];
    
    try {
        $stmt = $conn->prepare("
            SELECT la.*, u.name, u.email
            FROM leave_applications la
            JOIN users u ON la.user_id = u.id
            WHERE la.id = ? AND la.user_id = ?
        ");
        $stmt->execute([$leave_id, $user_id]);
        $leave = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($leave) {
            $start = new DateTime($leave['leave_start_date']);
            $end = new DateTime($leave['leave_end_date']);
            $interval = $start->diff($end);
            $total_days = $interval->days + 1;
            
            header('Content-Type: text/html');
            ?>
            <div class="leave-details">
                <div class="detail-grid">
                    <div class="detail-row">
                        <span class="label">Application ID:</span>
                        <span><?php echo $leave['id']; ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Teacher:</span>
                        <span><?php echo htmlspecialchars($leave['name']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Email:</span>
                        <span><?php echo htmlspecialchars($leave['email']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Teacher ID:</span>
                        <span><?php echo htmlspecialchars($leave['teacher_id']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Leave Type:</span>
                        <span><?php echo htmlspecialchars($leave['leave_type']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Dates:</span>
                        <span>
                            <?php echo date('M d, Y', strtotime($leave['leave_start_date'])); ?> 
                            to 
                            <?php echo date('M d, Y', strtotime($leave['leave_end_date'])); ?>
                            (<?php echo $total_days; ?> days)
                        </span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Status:</span>
                        <span class="status-badge <?php echo strtolower(str_replace(' ', '-', $leave['status'])); ?>">
                            <?php echo $leave['status']; ?>
                        </span>
                    </div>
                    <div class="detail-row full-width">
                        <span class="label">Description:</span>
                        <div class="description-box">
                            <?php echo nl2br(htmlspecialchars($leave['description'])); ?>
                        </div>
                    </div>
                    <?php if (!empty($leave['substitute_details'])): ?>
                    <div class="detail-row full-width">
                        <span class="label">Substitute Arrangements:</span>
                        <div class="description-box">
                            <?php echo nl2br(htmlspecialchars($leave['substitute_details'])); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="detail-row">
                        <span class="label">Submitted On:</span>
                        <span><?php echo date('M d, Y H:i', strtotime($leave['created_at'])); ?></span>
                    </div>
                </div>
            </div>
            <?php
        } else {
            header('HTTP/1.1 404 Not Found');
            echo "Leave application not found or access denied.";
        }
    } catch(PDOException $e) {
        header('HTTP/1.1 500 Internal Server Error');
        echo "Error loading leave details: " . $e->getMessage();
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    echo "Invalid request";
}
?>
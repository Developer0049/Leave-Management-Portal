<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch all notifications
$stmt = $conn->prepare("
    SELECT * FROM notifications 
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$stmt->execute([$user_id]);
$all_notifications = $stmt->fetchAll();

// Mark all as read when page is loaded
$stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
$stmt->execute([$user_id]);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - Leave Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="./css/main.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f7fa;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #2c3e50;
            margin-bottom: 20px;
        }
        /* Add the notification styles from earlier */
        .notifications-container {
            margin-top: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        /* ... include all the other CSS styles from earlier ... */
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Include your sidebar from main.php or recreate it here -->
        
        <div class="main-content">
            <header class="main-header">
                <h1><i class="fas fa-bell"></i> Notifications</h1>
                <div class="header-actions">
                    <a href="main.php" class="btn-icon">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                </div>
            </header>

            <div class="container">
                <div class="notifications-container">
                    <?php if (empty($all_notifications)): ?>
                        <div class="no-notifications">
                            <i class="fas fa-bell-slash"></i>
                            <p>No notifications found</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($all_notifications as $notification): ?>
                            <div class="notification">
                                <div class="notification-icon">
                                    <i class="fas <?php 
                                        echo $notification['type'] == 'approval' ? 'fa-check-circle' : 
                                             ($notification['type'] == 'rejection' ? 'fa-times-circle' : 'fa-info-circle'); 
                                    ?>"></i>
                                </div>
                                <div class="notification-content">
                                    <p><?php echo htmlspecialchars($notification['message']); ?></p>
                                    <small><?php echo date('M d, Y h:i A', strtotime($notification['created_at'])); ?></small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Add any necessary JavaScript here
    </script>
</body>
</html>
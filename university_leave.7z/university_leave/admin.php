<?php
session_start();

// Redirect if not admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}

// Include database connection
require_once 'includes/db.php';

// Check if connection was successful
if (!isset($conn)) {
    die("Database connection not established");
}

// Display email status messages
if (isset($_SESSION['email_sent']) && $_SESSION['email_sent']) {
    echo '<div class="alert alert-success">Email sent successfully.</div>';
    unset($_SESSION['email_sent']);
} elseif (isset($_SESSION['email_error'])) {
    echo '<div class="alert alert-danger">Failed to send email: ' . $_SESSION['email_error'] . '</div>';
    unset($_SESSION['email_error']);
}

// Initialize variables
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

// Base query with JOIN to users table
$query = "SELECT la.*, u.name as user_name, u.email as user_email 
          FROM leave_applications la
          JOIN users u ON la.user_id = u.id 
          WHERE 1=1";
$params = [];

// Add search conditions
if (!empty($search)) {
    $query .= " AND (la.teacher_id LIKE ? OR u.name LIKE ? OR u.email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Add status filter
if (!empty($status_filter)) {
    $query .= " AND la.status = ?";
    $params[] = $status_filter;
}

// Add date range filter
if (!empty($start_date) && !empty($end_date)) {
    $query .= " AND la.created_at BETWEEN ? AND ?";
    $params[] = $start_date;
    $params[] = $end_date;
}

// Count total records for pagination
$count_query = "SELECT COUNT(*) FROM leave_applications la JOIN users u ON la.user_id = u.id WHERE 1=1" .
               (!empty($search) ? " AND (la.teacher_id LIKE ? OR u.name LIKE ? OR u.email LIKE ?)" : "") .
               (!empty($status_filter) ? " AND la.status = ?" : "") .
               (!empty($start_date) && !empty($end_date) ? " AND la.created_at BETWEEN ? AND ?" : "");

$count_params = [];
if (!empty($search)) {
    $count_params = array_merge($count_params, ["%$search%", "%$search%", "%$search%"]);
}
if (!empty($status_filter)) {
    $count_params[] = $status_filter;
}
if (!empty($start_date) && !empty($end_date)) {
    $count_params = array_merge($count_params, [$start_date, $end_date]);
}

$stmt = $conn->prepare($count_query);
$stmt->execute($count_params);
$total_records = $stmt->fetchColumn();

// Pagination settings
$limit = 10;
$total_pages = ceil($total_records / $limit);
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max(1, min($page, $total_pages)); // Ensure page is within valid range
$offset = ($page - 1) * $limit;

// Final query with sorting and pagination
$query .= " ORDER BY la.created_at DESC LIMIT $limit OFFSET $offset";

// Execute main query
$stmt = $conn->prepare($query);
$stmt->execute($params);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['leave_id']) && isset($_POST['status'])) {
        $leave_id = $_POST['leave_id'];
        $status = $_POST['status'];
        
        try {
            // Check current status first
            $stmt = $conn->prepare("SELECT status FROM leave_applications WHERE id = ?");
            $stmt->execute([$leave_id]);
            $current_status = $stmt->fetchColumn();
            
            if ($current_status != 'Pending') {
                $_SESSION['error_message'] = "This leave application has already been processed.";
                header('Location: admin.php');
                exit();
            }
            
            // Update status
            $stmt = $conn->prepare("UPDATE leave_applications SET status = ? WHERE id = ?");
            $stmt->execute([$status, $leave_id]);
            
            $_SESSION['success_message'] = "Leave application status updated successfully.";
            header('Location: admin.php');
            exit();
            
        } catch(PDOException $e) {
            $_SESSION['error_message'] = "Database error: " . $e->getMessage();
            header('Location: admin.php');
            exit();
        }
    }
}
// Get monthly leave data for current year
$monthlyData = [];
$currentYear = date('Y');

// Build base query conditions based on filters
$baseConditions = "1=1";
$queryParams = [];

if (!empty($search)) {
    $baseConditions .= " AND (la.teacher_id LIKE ? OR u.name LIKE ? OR u.email LIKE ?)";
    array_push($queryParams, "%$search%", "%$search%", "%$search%");
}

if (!empty($status_filter)) {
    $baseConditions .= " AND la.status = ?";
    $queryParams[] = $status_filter;
}

if (!empty($start_date) && !empty($end_date)) {
    $baseConditions .= " AND la.created_at BETWEEN ? AND ?";
    array_push($queryParams, $start_date, $end_date);
}

for ($i = 1; $i <= 12; $i++) {
    $monthStart = sprintf('%04d-%02d-01', $currentYear, $i);
    $monthEnd = date('Y-m-t', strtotime($monthStart));
    
    // Pending
    $pendingQuery = "SELECT COUNT(*) FROM leave_applications la 
                    JOIN users u ON la.user_id = u.id
                    WHERE $baseConditions 
                    AND la.status = 'Pending'
                    AND la.created_at BETWEEN ? AND ?";
    
    $stmt = $conn->prepare($pendingQuery);
    $stmt->execute(array_merge($queryParams, [$monthStart, $monthEnd]));
    $pending = $stmt->fetchColumn();
    
    // Approved
    $approvedQuery = "SELECT COUNT(*) FROM leave_applications la 
                     JOIN users u ON la.user_id = u.id
                     WHERE $baseConditions 
                     AND la.status = 'Approved'
                     AND la.created_at BETWEEN ? AND ?";
    
    $stmt = $conn->prepare($approvedQuery);
    $stmt->execute(array_merge($queryParams, [$monthStart, $monthEnd]));
    $approved = $stmt->fetchColumn();
    
    // Not Approved
    $notApprovedQuery = "SELECT COUNT(*) FROM leave_applications la 
                        JOIN users u ON la.user_id = u.id
                        WHERE $baseConditions 
                        AND la.status = 'Not Approved'
                        AND la.created_at BETWEEN ? AND ?";
    
    $stmt = $conn->prepare($notApprovedQuery);
    $stmt->execute(array_merge($queryParams, [$monthStart, $monthEnd]));
    $notApproved = $stmt->fetchColumn();
    
    $monthlyData[] = [
        'pending' => $pending,
        'approved' => $approved,
        'notApproved' => $notApproved
    ];
}

// Get status counts with filters applied
$statusCounts = [
    'Pending' => 0,
    'Approved' => 0,
    'Not Approved' => 0
];

foreach ($statusCounts as $status => &$count) {
    $query = "SELECT COUNT(*) FROM leave_applications la 
             JOIN users u ON la.user_id = u.id
             WHERE $baseConditions";
    
    // Add status condition if not already in filters
    if (empty($status_filter)) {
        $query .= " AND la.status = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute(array_merge($queryParams, [$status]));
    } else {
        // If status filter is applied, we only need to count that status
        if ($status_filter == $status) {
            $stmt = $conn->prepare($query);
            $stmt->execute($queryParams);
        } else {
            continue; // Skip other statuses if filtered
        }
    }
    
    $count = $stmt->fetchColumn();
}
    // After approving/rejecting leave in admin.php
    if ($status == 'Approved') {
        $stmt = $conn->prepare("UPDATE leave_balances 
                               SET cl_balance = cl_balance - ? 
                               WHERE user_id = ? AND year = YEAR(NOW())");
        $stmt->execute([$leave_days, $user_id]);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Leave Management System</title>
    <link rel="stylesheet" href="./admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-user-shield"></i> Admin Panel</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li class="active"><a href="admin.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="manage_users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                    <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <img src="https://ui-avatars.com/api/?name=Admin&size=40&background=0D8ABC&color=fff" alt="Admin Avatar" style="padding: 10px; border-radius: 25px;">
                    <div>
                        <span class="username"><?php echo $_SESSION['name'] ?? 'Admin'; ?></span>
                        <span class="role">Administrator</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <header class="main-header">
            <button class="mobile-menu-toggle">
        <i class="fas fa-bars"></i>
    </button>
                <h1><i class="fas fa-clipboard-check"></i> Leave Applications Management</h1>
                <div class="header-actions">
                    <button id="notifications-btn" class="btn-icon">
                        <i class="fas fa-bell"></i>
                        <span class="badge">3</span>
                    </button>
                </div>
            </header>

            <!-- Status Messages -->
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger">
                    <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                </div>
            <?php endif; ?>

            <!-- Dashboard Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Pending</h3>
                        <p>
                            <?php 
                            $stmt = $conn->query("SELECT COUNT(*) FROM leave_applications WHERE status = 'Pending'");
                            echo $stmt->fetchColumn(); 
                            ?>
                        </p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon approved">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Approved</h3>
                        <p>
                            <?php 
                            $stmt = $conn->query("SELECT COUNT(*) FROM leave_applications WHERE status = 'Approved'");
                            echo $stmt->fetchColumn(); 
                            ?>
                        </p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon rejected">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Rejected</h3>
                        <p>
                            <?php 
                            $stmt = $conn->query("SELECT COUNT(*) FROM leave_applications WHERE status = 'Not Approved'");
                            echo $stmt->fetchColumn(); 
                            ?>
                        </p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total</h3>
                        <p><?php echo $total_records; ?></p>
                    </div>
                </div>
            </div>

            <!-- Charts Section -->
            <div class="charts-row">
                <div class="chart-container">
                    <canvas id="statusChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="monthlyTrendChart"></canvas>
                </div>
            </div>

            <!-- Search and Filter Section -->
            <div class="card filter-card">
                <div class="card-header">
                    <h3><i class="fas fa-filter"></i> Filter Applications</h3>
                    <button id="toggle-filter" class="btn-icon"><i class="fas fa-chevron-down"></i></button>
                </div>
                <div class="card-body filter-body">
                    <form action="admin.php" method="GET" class="search-filter-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="search"><i class="fas fa-search"></i> Search</label>
                                <input type="text" id="search" name="search" placeholder="Teacher ID, Name or Email" value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="form-group">
                                <label for="status"><i class="fas fa-tag"></i> Status</label>
                                <select id="status" name="status">
                                    <option value="">All Statuses</option>
                                    <option value="Pending" <?php echo $status_filter == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Approved" <?php echo $status_filter == 'Approved' ? 'selected' : ''; ?>>Approved</option>
                                    <option value="Not Approved" <?php echo $status_filter == 'Not Approved' ? 'selected' : ''; ?>>Not Approved</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="start_date"><i class="fas fa-calendar-day"></i> From</label>
                                <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>">
                            </div>
                            <div class="form-group">
                                <label for="end_date"><i class="fas fa-calendar-day"></i> To</label>
                                <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>">
                            </div>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn-primary"><i class="fas fa-filter"></i> Apply Filters</button>
                            <button type="button" id="reset-filters" class="btn-secondary"><i class="fas fa-broom"></i> Reset</button>
                            <button type="submit" formaction="download_all_leave.php" class="btn-download">
                                <i class="fas fa-file-pdf"></i> Export as PDF
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Applications Table -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> Leave Applications</h3>
                    <div class="table-actions">
                        <span>Showing <?php echo count($applications); ?> of <?php echo $total_records; ?> records</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Teacher</th>
                                    <th>Leave Type</th>
                                    <th>Dates</th>
                                    <th>Days</th>
                                    <th>Status</th>
                                    <th>Submitted</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($applications as $app): ?>
                                    <tr>
                                        <td><?php echo $app['id']; ?></td>
                                        <td>
                                            <div class="user-cell">
                                                <div class="user-avatar"><?php echo substr($app['user_name'], 0, 1); ?></div>
                                                <div>
                                                    <div class="user-name"><?php echo htmlspecialchars($app['user_name']); ?></div>
                                                    <div class="user-id"><?php echo htmlspecialchars($app['teacher_id']); ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo htmlspecialchars($app['leave_type']); ?></td>
                                        <td>
                                            <?php echo date('M d', strtotime($app['leave_start_date'])); ?> - 
                                            <?php echo date('M d, Y', strtotime($app['leave_end_date'])); ?>
                                        </td>
                                        <td>
                                            <?php 
                                            $start = new DateTime($app['leave_start_date']);
                                            $end = new DateTime($app['leave_end_date']);
                                            $interval = $start->diff($end);
                                            echo $interval->days + 1; // +1 to include both start and end dates
                                            ?>
                                        </td>
                                        <td>
                                            <span class="status-badge <?php echo strtolower(str_replace(' ', '-', $app['status'])); ?>">
                                                <?php echo $app['status']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($app['created_at'])); ?></td>
                                        <td>
                                            <div class="action-buttons">
                                                <?php if ($app['status'] == 'Pending'): ?>
                                                    <form action="admin.php" method="POST" style="display: inline;">
                                                        <input type="hidden" name="leave_id" value="<?php echo $app['id']; ?>">
                                                        <button type="submit" name="status" value="Approved" class="btn-action btn-approve">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    </form>
                                                    <form action="admin.php" method="POST" style="display: inline;">
                                                        <input type="hidden" name="leave_id" value="<?php echo $app['id']; ?>">
                                                        <button type="submit" name="status" value="Not Approved" class="btn-action btn-reject">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <button class="btn-action" disabled>
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                    <button class="btn-action" disabled>
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <form action="send_email.php" method="POST" style="display: inline;">
                                                    <input type="hidden" name="leave_id" value="<?php echo $app['id']; ?>">
                                                    <button type="submit" class="btn-action btn-email">
                                                        <i class="fas fa-envelope"></i>
                                                    </button>
                                                </form>
                                                <a href="download_leave.php?id=<?php echo $app['id']; ?>" class="btn-action btn-download">
                                                    <i class="fas fa-download"></i>
                                                </a>
                                                <button class="btn-action btn-view" data-leave-id="<?php echo $app['id']; ?>">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="admin.php?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>" class="page-nav">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        <?php endif; ?>
                        
                        <?php 
                        $start_page = max(1, $page - 2);
                        $end_page = min($total_pages, $start_page + 4);
                        
                        if ($start_page > 1): ?>
                            <a href="admin.php?page=1&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>">1</a>
                            <?php if ($start_page > 2): ?>
                                <span class="page-dots">...</span>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                            <a href="admin.php?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>"
                               class="<?php echo $page == $i ? 'active' : ''; ?>">
                                <?php echo $i; ?>
                            </a>
                        <?php endfor; ?>
                        
                        <?php if ($end_page < $total_pages): ?>
                            <?php if ($end_page < $total_pages - 1): ?>
                                <span class="page-dots">...</span>
                            <?php endif; ?>
                            <a href="admin.php?page=<?php echo $total_pages; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>">
                                <?php echo $total_pages; ?>
                            </a>
                        <?php endif; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="admin.php?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>" class="page-nav">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Application Detail Modal -->
    <div id="applicationModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Leave Application Details</h3>
                <button class="close-modal">&times;</button>
            </div>
            <div class="modal-body" id="modalContent">
                <!-- Content will be loaded via AJAX -->
            </div>
            <div class="modal-footer">
                <button class="btn-secondary close-modal">Close</button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (mobileToggle && sidebar) {
        mobileToggle.addEventListener('click', function() {
            sidebar.classList.toggle('mobile-visible');
        });
    }
    
    // Close menu when clicking on a link
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
        link.addEventListener('click', function() {
            sidebar.classList.remove('mobile-visible');
        });
    });
});
document.addEventListener('DOMContentLoaded', function() {
            // Status Distribution Chart
            const statusCtx = document.getElementById('statusChart').getContext('2d');
            const statusChart = new Chart(statusCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Pending', 'Approved', 'Not Approved'],
                    datasets: [{
                        data: [
                            <?php echo $statusCounts['Pending']; ?>,
                            <?php echo $statusCounts['Approved']; ?>,
                            <?php echo $statusCounts['Not Approved']; ?>
                        ],
                        backgroundColor: [
                            '#FFC107',
                            '#28A745',
                            '#DC3545'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'right',
                        },
                        title: {
                            display: true,
                            text: 'Leave Applications Status Distribution'
                        }
                    }
                }
            });

            // Monthly Trend Chart
            const monthlyCtx = document.getElementById('monthlyTrendChart').getContext('2d');
            const monthlyChart = new Chart(monthlyCtx, {
                type: 'bar',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    datasets: [
                        {
                            label: 'Pending',
                            data: [<?php echo implode(',', array_column($monthlyData, 'pending')); ?>],
                            backgroundColor: '#FFC107'
                        },
                        {
                            label: 'Approved',
                            data: [<?php echo implode(',', array_column($monthlyData, 'approved')); ?>],
                            backgroundColor: '#28A745'
                        },
                        {
                            label: 'Not Approved',
                            data: [<?php echo implode(',', array_column($monthlyData, 'notApproved')); ?>],
                            backgroundColor: '#DC3545'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        x: {
                            stacked: true,
                        },
                        y: {
                            stacked: true,
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: 'Monthly Leave Applications Trend (<?php echo $currentYear; ?>)'
                        }
                    }
                }
            });


            // Toggle filter section
            document.getElementById('toggle-filter').addEventListener('click', function() {
                const filterBody = document.querySelector('.filter-body');
                const icon = this.querySelector('i');
                
                filterBody.classList.toggle('collapsed');
                if (filterBody.classList.contains('collapsed')) {
                    icon.classList.remove('fa-chevron-down');
                    icon.classList.add('fa-chevron-up');
                } else {
                    icon.classList.remove('fa-chevron-up');
                    icon.classList.add('fa-chevron-down');
                }
            });

            // Reset filters
            document.getElementById('reset-filters').addEventListener('click', function() {
                window.location.href = 'admin.php';
            });

            // View application details
            document.querySelectorAll('.btn-view').forEach(btn => {
                btn.addEventListener('click', function() {
                    const leaveId = this.getAttribute('data-leave-id');
                    fetch(`get_application_details.php?id=${leaveId}`)
                        .then(response => response.text())
                        .then(data => {
                            document.getElementById('modalContent').innerHTML = data;
                            document.getElementById('applicationModal').style.display = 'block';
                        });
                });
            });
            
            // Confirmation for approve/reject
            document.querySelectorAll('form[action="admin.php"]').forEach(form => {
                form.addEventListener('submit', function(e) {
                    const status = this.querySelector('button[type="submit"]').value;
                    if (!confirm(`Are you sure you want to ${status.toLowerCase()} this leave application?`)) {
                        e.preventDefault();
                    }
                });
            });

            // Close modals
            document.querySelectorAll('.close-modal').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.getElementById('applicationModal').style.display = 'none';
                });
            });
            
            // Close when clicking outside modal
            window.addEventListener('click', function(event) {
                if (event.target === document.getElementById('applicationModal')) {
                    document.getElementById('applicationModal').style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
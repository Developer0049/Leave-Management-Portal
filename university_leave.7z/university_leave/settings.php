<?php
session_start();

// Redirect if not admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}

require_once 'includes/db.php';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Update system settings
        if (isset($_POST['update_settings'])) {
            $site_name = $_POST['site_name'];
            $items_per_page = (int)$_POST['items_per_page'];
            $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
            
            // In a real system, you would save these to a settings table
            $_SESSION['success_message'] = "System settings updated successfully.";
            header('Location: settings.php');
            exit();
        }
        
        // Update admin password
        if (isset($_POST['change_password'])) {
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            // Verify current password
            $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            
            if (!password_verify($current_password, $user['password'])) {
                $_SESSION['error_message'] = "Current password is incorrect.";
                header('Location: settings.php');
                exit();
            }
            
            if ($new_password != $confirm_password) {
                $_SESSION['error_message'] = "New passwords do not match.";
                header('Location: settings.php');
                exit();
            }
            
            if (strlen($new_password) < 8) {
                $_SESSION['error_message'] = "Password must be at least 8 characters.";
                header('Location: settings.php');
                exit();
            }
            
            // Update password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed_password, $_SESSION['user_id']]);
            
            $_SESSION['success_message'] = "Password updated successfully.";
            header('Location: settings.php');
            exit();
        }
    } catch(PDOException $e) {
        $_SESSION['error_message'] = "Database error: " . $e->getMessage();
        header('Location: settings.php');
        exit();
    }
}

// Get current settings (in a real system, from database)
$site_name = "Leave Management System";
$items_per_page = 10;
$email_notifications = 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings | Leave Management System</title>
    <link rel="stylesheet" href="./admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-user-shield"></i> Admin Panel</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="admin.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="manage_users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                    <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    <li class="active"><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <img src="https://via.placeholder.com/40" alt="Admin Avatar">
                    <div>
                        <span class="username"><?php echo $_SESSION['name'] ?? 'Admin'; ?></span>
                        <span class="role">Administrator</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <header class="main-header">
                <h1><i class="fas fa-cogs"></i> System Settings</h1>
            </header>

            <!-- Status Messages -->
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger">
                    <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                </div>
            <?php endif; ?>

            <!-- System Settings -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-sliders-h"></i> General Settings</h3>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-group">
                            <label for="site_name">System Name</label>
                            <input type="text" id="site_name" name="site_name" value="<?= htmlspecialchars($site_name) ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="items_per_page">Items Per Page</label>
                            <select id="items_per_page" name="items_per_page">
                                <option value="5" <?= $items_per_page == 5 ? 'selected' : '' ?>>5</option>
                                <option value="10" <?= $items_per_page == 10 ? 'selected' : '' ?>>10</option>
                                <option value="20" <?= $items_per_page == 20 ? 'selected' : '' ?>>20</option>
                                <option value="50" <?= $items_per_page == 50 ? 'selected' : '' ?>>50</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="email_notifications" value="1" <?= $email_notifications ? 'checked' : '' ?>>
                                Enable Email Notifications
                            </label>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" name="update_settings" class="btn-primary">
                                <i class="fas fa-save"></i> Save Settings
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Password Change -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-key"></i> Change Password</h3>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-group">
                            <label for="current_password">Current Password</label>
                            <input type="password" id="current_password" name="current_password" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <input type="password" id="new_password" name="new_password" required>
                            <small class="form-text">Minimum 8 characters</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm New Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" required>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" name="change_password" class="btn-primary">
                                <i class="fas fa-key"></i> Change Password
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- System Information -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-info-circle"></i> System Information</h3>
                </div>
                <div class="card-body">
                    <div class="system-info">
                        <div class="info-item">
                            <span class="info-label">PHP Version:</span>
                            <span class="info-value"><?= phpversion() ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Database:</span>
                            <span class="info-value">MySQL</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Server Software:</span>
                            <span class="info-value"><?= $_SERVER['SERVER_SOFTWARE'] ?? 'N/A' ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">System Version:</span>
                            <span class="info-value">1.0.0</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Password strength indicator
        document.getElementById('new_password').addEventListener('input', function() {
            const password = this.value;
            const strength = calculatePasswordStrength(password);
            const hint = this.nextElementSibling;
            
            if (password.length === 0) {
                hint.textContent = 'Minimum 8 characters';
                hint.style.color = '';
            } else if (password.length < 8) {
                hint.textContent = 'Password too short';
                hint.style.color = '#dc3545';
            } else {
                hint.textContent = 'Password strength: ' + strength;
                hint.style.color = strength === 'Strong' ? '#28a745' : 
                                  strength === 'Medium' ? '#ffc107' : '#dc3545';
            }
        });

        function calculatePasswordStrength(password) {
            const hasUpper = /[A-Z]/.test(password);
            const hasLower = /[a-z]/.test(password);
            const hasNumber = /\d/.test(password);
            const hasSpecial = /[^A-Za-z0-9]/.test(password);
            
            let strength = 0;
            if (password.length >= 8) strength++;
            if (hasUpper && hasLower) strength++;
            if (hasNumber) strength++;
            if (hasSpecial) strength++;
            
            if (strength < 2) return 'Weak';
            if (strength < 4) return 'Medium';
            return 'Strong';
        }
    </script>
</body>
</html>

<?php
session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once 'includes/db.php';

// Fetch user details
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Fetch leave stats for dashboard
$stmt = $conn->prepare("
    SELECT 
        SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'Not Approved' THEN 1 ELSE 0 END) as rejected,
        COUNT(*) as total
    FROM leave_applications 
    WHERE user_id = ?
");
$stmt->execute([$user_id]);
$leave_stats = $stmt->fetch();

// Fetch recent leave applications
$stmt = $conn->prepare("
    SELECT * FROM leave_applications 
    WHERE user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 5
");

// Fetch unread notifications
$stmt = $conn->prepare("
    SELECT * FROM notifications 
    WHERE user_id = ? AND is_read = 0 
    ORDER BY created_at DESC 
    LIMIT 10
");
$stmt->execute([$user_id]); // Execute with user_id parameter
$notifications = $stmt->fetchAll();
$notification_count = count($notifications);

// Then fetch recent leave applications (this was out of order)
$stmt = $conn->prepare("
    SELECT * FROM leave_applications 
    WHERE user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 5
");

$stmt->execute([$user_id]);
$recent_leaves = $stmt->fetchAll();
// Fetch Indian holidays (Bangalore specific)
function getIndianHolidays($year) {
    // Static list - you might want to use an API or database for this
    $holidays = [
        $year.'-01-26' => 'Republic Day',
        $year.'-03-22' => 'Ugadi',
        $year.'-05-01' => 'Labour Day',
        $year.'-08-15' => 'Independence Day',
        $year.'-10-02' => 'Gandhi Jayanti',
        $year.'-10-24' => 'Vijay Dashami',
        $year.'-12-25' => 'Christmas',
        // Add more Bangalore-specific holidays as needed
    ];
    
    return $holidays;
}

// Fetch all leaves for the current user
$stmt = $conn->prepare("
    SELECT 
        id,
        leave_start_date,
        leave_end_date,
        status,
        leave_type
    FROM leave_applications 
    WHERE user_id = ?
");
$stmt->execute([$user_id]);
$all_leaves = $stmt->fetchAll();

// Prepare leaves for FullCalendar
$calendar_events = [];
foreach ($all_leaves as $leave) {
    $color = '#FFA500'; // Orange for pending (default)
    if ($leave['status'] == 'Approved') $color = '#28a745'; // Green
    if ($leave['status'] == 'Not Approved') $color = '#dc3545'; // Red
    
    $calendar_events[] = [
        'id' => $leave['id'],
        'title' => $leave['leave_type'],
        'start' => $leave['leave_start_date'],
        'end' => date('Y-m-d', strtotime($leave['leave_end_date'] . ' +1 day')),
        'color' => $color,
        'extendedProps' => [
            'status' => $leave['status']
        ]
    ];
}

// Get holidays for current year
$currentYear = date('Y');
$holidays = getIndianHolidays($currentYear);
foreach ($holidays as $date => $name) {
    $calendar_events[] = [
        'title' => $name,
        'start' => $date,
        'color' => '#6c757d', // Gray for holidays
        'display' => 'background',
        'extendedProps' => [
            'isHoliday' => true
        ]
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Management Dashboard</title>
    <!-- Add these in your <head> -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="./css/main.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-calendar-alt"></i> Leave Portal</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li class="active"><a href="main.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="#apply-leave"><i class="fas fa-file-signature"></i> Apply for Leave</a></li>
                    <li><a href="leave_history.php"><i class="fas fa-history"></i> Leave History</a></li>
                    <li><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($user['name'], 0, 1)); ?></div>
                    <div>
                        <span class="username"><?php echo htmlspecialchars($user['name']); ?></span>
                        <span class="role"><?php echo ucfirst($user['role']); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <header class="main-header">
            <button class="mobile-menu-toggle">
        <i class="fas fa-bars"></i>
    </button>
                <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
                <div class="header-actions">
    <div class="notifications-dropdown">
        <button id="notifications-btn" class="btn-icon">
            <i class="fas fa-bell"></i>
            <?php if ($notification_count > 0): ?>
                <span class="badge"><?php echo $notification_count; ?></span>
            <?php endif; ?>
        </button>
        <div class="notifications-menu">
            <div class="notifications-header">
                <h4>Notifications</h4>
                <?php if ($notification_count > 0): ?>
                    <button id="mark-all-read" class="btn-link">Mark all as read</button>
                <?php endif; ?>
            </div>
            <div class="notifications-list">
                <?php if (empty($notifications)): ?>
                    <div class="notification-item empty">No new notifications</div>
                <?php else: ?>
                    <?php foreach ($notifications as $notification): ?>
                        <div class="notification-item <?php echo !$notification['is_read'] ? 'unread' : ''; ?>" data-notification-id="<?php echo $notification['id']; ?>">
                            <div class="notification-icon">
                                <i class="fas <?php 
                                    echo $notification['type'] == 'approval' ? 'fa-check-circle' : 
                                         ($notification['type'] == 'rejection' ? 'fa-times-circle' : 'fa-info-circle'); 
                                ?>"></i>
                            </div>
                            <div class="notification-content">
                                <p><?php echo htmlspecialchars($notification['message']); ?></p>
                                <small><?php echo date('M d, Y h:i A', strtotime($notification['created_at'])); ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="notifications-footer">
                <a href="notifications.php" class="btn-link">View all notifications</a>
            </div>
        </div>
    </div>
</div>
            </header>

            <!-- Dashboard Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Leaves Applied</h3>
                        <p><?php echo $leave_stats['total'] ?? 0; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon approved">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Approved</h3>
                        <p><?php echo $leave_stats['approved'] ?? 0; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Pending</h3>
                        <p><?php echo $leave_stats['pending'] ?? 0; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon rejected">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Not Accepted</h3>
                        <p><?php echo $leave_stats['rejected'] ?? 0; ?></p>
                    </div>
                </div>
            </div>
            <!-- Calendar Section -->
<!-- Replace your existing calendar card with this -->
<div class="card calendar-card">
    <div class="card-header">
        <h3><i class="fas fa-calendar-alt"></i> Leave Calendar</h3>
        <div class="calendar-controls">
            <button id="calendar-prev" class="btn-icon"><i class="fas fa-chevron-left"></i></button>
            <button id="calendar-today" class="btn-icon">Today</button>
            <button id="calendar-next" class="btn-icon"><i class="fas fa-chevron-right"></i></button>
            <div class="calendar-view-toggle">
                <button class="btn-icon active" data-view="dayGridMonth"><i class="fas fa-calendar"></i></button>
                <button class="btn-icon" data-view="timeGridWeek"><i class="fas fa-calendar-week"></i></button>
                <button class="btn-icon" data-view="timeGridDay"><i class="fas fa-calendar-day"></i></button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div id="leaveCalendar"></div>
        <div class="calendar-legend">
            <div class="legend-item">
                <span class="legend-color approved"></span>
                <span>Approved Leave</span>
            </div>
            <div class="legend-item">
                <span class="legend-color pending"></span>
                <span>Pending Leave</span>
            </div>
            <div class="legend-item">
                <span class="legend-color rejected"></span>
                <span>Rejected Leave</span>
            </div>
            <div class="legend-item">
                <span class="legend-color holiday"></span>
                <span>Holiday</span>
            </div>
            <div class="legend-item">
                <span class="legend-color weekend"></span>
                <span>Weekend</span>
            </div>
        </div>
    </div>
</div>

            <!-- Recent Leave Applications -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-history"></i> Recent Leave Applications</h3>
                    <a href="leave_history.php" class="btn-link">View All</a>
                </div>
                <div class="card-body">
                    <?php if (empty($recent_leaves)): ?>
                        <p class="no-data">No leave applications found.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Leave Type</th>
                                        <th>Dates</th>
                                        <th>Days</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_leaves as $leave): ?>
                                        <?php
                                        $start = new DateTime($leave['leave_start_date']);
                                        $end = new DateTime($leave['leave_end_date']);
                                        $interval = $start->diff($end);
                                        $total_days = $interval->days + 1;
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($leave['leave_type']); ?></td>
                                            <td>
                                                <?php echo date('M d', strtotime($leave['leave_start_date'])); ?> - 
                                                <?php echo date('M d, Y', strtotime($leave['leave_end_date'])); ?>
                                            </td>
                                            <td><?php echo $total_days; ?></td>
                                            <td>
                                                <span class="status-badge <?php echo strtolower(str_replace(' ', '-', $leave['status'])); ?>">
                                                    <?php echo $leave['status']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn-action btn-view" data-leave-id="<?php echo $leave['id']; ?>">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <?php if ($leave['status'] == 'Pending'): ?>
                                                    <button class="btn-action btn-cancel" data-leave-id="<?php echo $leave['id']; ?>">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Leave Application Form -->
            <div class="card" id="apply-leave">
                <div class="card-header">
                    <h3><i class="fas fa-file-signature"></i> Apply for Leave</h3>
                </div>
                <div class="card-body">
                    <form id="leaveForm" action="submit_leave.php" method="POST">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="teacher_id">Teacher ID</label>
                                <input type="text" id="teacher_id" name="teacher_id" value="<?php echo htmlspecialchars($user['id']); ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="leave_type">Leave Type</label>
                                <select id="leave_type" name="leave_type" required>
                                    <option value="">Select Leave Type</option>
                                    <option value="Sick Leave">Sick Leave</option>
                                    <option value="Vacation">Vacation</option>
                                    <option value="Personal Leave">Personal Leave</option>
                                    <option value="Maternity/Paternity">Maternity/Paternity</option>
                                    <option value="Bereavement">Bereavement</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="leave_start_date">Leave Start Date</label>
                                <input type="date" id="leave_start_date" name="leave_start_date" required>
                            </div>
                            <div class="form-group">
                                <label for="leave_end_date">Leave End Date</label>
                                <input type="date" id="leave_end_date" name="leave_end_date" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="description">Reason for Leave</label>
                            <textarea id="description" name="description" rows="4" required></textarea>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="substitute_allotted">Substitute Teacher Allotted?</label>
                                <select id="substitute_allotted" name="substitute_allotted" required>
                                    <option value="0">No</option>
                                    <option value="1">Yes</option>
                                </select>
                            </div>
                            <div class="form-group" id="substitute-details-group" style="display: none;">
                                <label for="substitute_details">Substitute Teacher Details</label>
                                <textarea id="substitute_details" name="substitute_details" rows="3"></textarea>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="attachment">Supporting Documents (if any)</label>
                            <input type="file" id="attachment" name="attachment" accept=".pdf,.jpg,.png,.doc,.docx">
                            <small class="form-text">Max file size: 2MB (PDF, JPG, PNG, DOC)</small>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn-primary">
                                <i class="fas fa-paper-plane"></i> Submit Application
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Upcoming Holidays
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-calendar-day"></i> Upcoming Holidays</h3>
                </div>
                <div class="card-body">
                    <div class="holidays-list">
                        <div class="holiday-item">
                            <div class="holiday-date">May 1</div>
                            <div class="holiday-name">Labor Day</div>
                        </div>
                        <div class="holiday-item">
                            <div class="holiday-date">June 12</div>
                            <div class="holiday-name">Independence Day</div>
                        </div>
                        <div class="holiday-item">
                            <div class="holiday-date">August 30</div>
                            <div class="holiday-name">National Heroes Day</div>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
    </div>

    <!-- Leave Details Modal -->
    <div id="leaveModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Leave Application Details</h3>
                <button class="close-modal">&times;</button>
            </div>
            <div class="modal-body" id="modalContent">
                <!-- Content loaded via AJAX -->
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (mobileToggle && sidebar) {
        mobileToggle.addEventListener('click', function() {
            sidebar.classList.toggle('mobile-visible');
        });
    }
    
    // Close menu when clicking on a link
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
        link.addEventListener('click', function() {
            sidebar.classList.remove('mobile-visible');
        });
    });
});
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle substitute details
            document.getElementById('substitute_allotted').addEventListener('change', function() {
                const detailsGroup = document.getElementById('substitute-details-group');
                detailsGroup.style.display = this.value == '1' ? 'block' : 'none';
            });

            // Date validation
            document.getElementById('leaveForm').addEventListener('submit', function(e) {
                const startDate = new Date(document.getElementById('leave_start_date').value);
                const endDate = new Date(document.getElementById('leave_end_date').value);
                
                if (endDate < startDate) {
                    alert('Leave end date cannot be earlier than start date.');
                    e.preventDefault();
                }
                
                // Additional validation can be added here
            });

            // View leave details
            document.querySelectorAll('.btn-view').forEach(btn => {
                btn.addEventListener('click', function() {
                    const leaveId = this.getAttribute('data-leave-id');
                    fetch(`get_leave_details.php?id=${leaveId}`)
                        .then(response => response.text())
                        .then(data => {
                            document.getElementById('modalContent').innerHTML = data;
                            document.getElementById('leaveModal').style.display = 'block';
                        });
                });
            });

            // Cancel leave application
            document.querySelectorAll('.btn-cancel').forEach(btn => {
                btn.addEventListener('click', function() {
                    const leaveId = this.getAttribute('data-leave-id');
                    if (confirm('Are you sure you want to cancel this leave application?')) {
                        fetch(`cancel_leave.php?id=${leaveId}`)
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    location.reload();
                                } else {
                                    alert(data.error || 'Failed to cancel leave');
                                }
                            });
                    }
                });
            });

            // Close modal
            document.querySelectorAll('.close-modal').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.getElementById('leaveModal').style.display = 'none';
                });
            });

            // Close modal when clicking outside
            window.addEventListener('click', function(e) {
                if (e.target === document.getElementById('leaveModal')) {
                    document.getElementById('leaveModal').style.display = 'none';
                }
            });
        });

        // Notification functionality
document.addEventListener('DOMContentLoaded', function() {
    // Toggle notification read status when clicked
    document.querySelectorAll('.notification-item').forEach(item => {
        item.addEventListener('click', function() {
            const notificationId = this.getAttribute('data-notification-id');
            if (notificationId) {
                markNotificationAsRead(notificationId);
                this.classList.remove('unread');
            }
        });
    });

    // Mark all as read
    const markAllReadBtn = document.getElementById('mark-all-read');
    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            fetch('mark_all_notifications_read.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ user_id: <?php echo $user_id; ?> })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.querySelectorAll('.notification-item.unread').forEach(item => {
                        item.classList.remove('unread');
                    });
                    const badge = document.querySelector('.badge');
                    if (badge) {
                        badge.style.display = 'none';
                    }
                }
            });
        });
    }
});

function markNotificationAsRead(notificationId) {
    fetch('mark_notification_read.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ notification_id: notificationId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update badge count
            const badge = document.querySelector('.badge');
            if (badge) {
                const count = parseInt(badge.textContent) - 1;
                if (count > 0) {
                    badge.textContent = count;
                } else {
                    badge.style.display = 'none';
                }
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('leaveCalendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: {
    url: 'get_holidays.php',
    method: 'GET',
    failure: function() {
        alert('Error fetching holidays');
    }
},
        events: <?php echo json_encode($calendar_events); ?>,
        eventClick: function(info) {
            if (info.event.extendedProps.isHoliday) {
                alert('Holiday: ' + info.event.title);
            } else {
                // Show leave details
                fetch(`get_leave_details.php?id=${info.event.id}`)
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('modalContent').innerHTML = data;
                        document.getElementById('leaveModal').style.display = 'block';
                    });
            }
        },
        eventDidMount: function(info) {
            // Add tooltips
            if (info.event.extendedProps.isHoliday) {
                info.el.setAttribute('title', 'Holiday: ' + info.event.title);
            } else {
                info.el.setAttribute('title', 
                    info.event.title + ' (' + info.event.extendedProps.status + ')');
            }
        }
    });
    calendar.render();
});
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('leaveCalendar');
    
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: false, // We're using custom controls
        height: 'auto',
        aspectRatio: 1.5,
        dayMaxEvents: 3,
        eventDisplay: 'block',
        eventTimeFormat: {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        },
        events: {
            url: 'get_holidays.php',
            method: 'GET',
            failure: function() {
                showToast('Error loading holidays', 'error');
            }
        },
        eventDidMount: function(info) {
            // Add status class for styling
            if (info.event.extendedProps.status) {
                info.el.classList.add(info.event.extendedProps.status.toLowerCase());
            }
            
            // Enhanced tooltip
            info.el.setAttribute('title', 
                info.event.title + 
                (info.event.extendedProps.status ? ' (' + info.event.extendedProps.status + ')' : '') +
                (info.event.start ? '\n' + info.event.start.toLocaleDateString() : '')
            );
        },
        dateClick: function(info) {
            // Auto-fill date when clicking on calendar
            document.getElementById('leave_start_date').value = info.dateStr;
            document.getElementById('leave_end_date').value = info.dateStr;
            
            // Scroll to leave form
            document.getElementById('apply-leave').scrollIntoView({
                behavior: 'smooth'
            });
        },
        eventClick: function(info) {
            if (info.event.extendedProps.isHoliday) {
                showToast('Holiday: ' + info.event.title, 'info');
            } else {
                fetch(`get_leave_details.php?id=${info.event.id}`)
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('modalContent').innerHTML = data;
                        document.getElementById('leaveModal').style.display = 'block';
                    });
            }
        }
    });

    calendar.render();
    
    // Custom controls
    document.getElementById('calendar-prev').addEventListener('click', function() {
        calendar.prev();
    });
    
    document.getElementById('calendar-next').addEventListener('click', function() {
        calendar.next();
    });
    
    document.getElementById('calendar-today').addEventListener('click', function() {
        calendar.today();
    });
    
    document.querySelectorAll('.calendar-view-toggle button').forEach(button => {
        button.addEventListener('click', function() {
            document.querySelectorAll('.calendar-view-toggle button').forEach(btn => {
                btn.classList.remove('active');
            });
            this.classList.add('active');
            calendar.changeView(this.dataset.view);
        });
    });
    
    // Add your leaves to the calendar
    fetch('get_leaves.php')
        .then(response => response.json())
        .then(data => {
            data.forEach(event => {
                calendar.addEvent(event);
            });
        })
        .catch(error => {
            showToast('Error loading leave data', 'error');
        });
});

function showToast(message, type = 'success') {
    // Implement a toast notification system
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

</script>
    </script>
</body>
</html>
<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 403 Forbidden');
    exit();
}

if (isset($_GET['id'])) {
    $leave_id = $_GET['id'];
    
    try {
        // Fetch full details from database
        $stmt = $conn->prepare("
            SELECT 
                la.*, 
                u.name, 
                u.email,
                la.teacher_id  /* Changed from u.teacher_id to la.teacher_id */
            FROM leave_applications la
            JOIN users u ON la.user_id = u.id
            WHERE la.id = ?
        ");
        $stmt->execute([$leave_id]);
        $application = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$application) {
            header('HTTP/1.1 404 Not Found');
            exit();
        }

        // Calculate total days
        $start = new DateTime($application['leave_start_date']);
        $end = new DateTime($application['leave_end_date']);
        $interval = $start->diff($end);
        $total_days = $interval->days + 1; // +1 to include both start and end dates

        // Generate HTML for the modal
        header('Content-Type: text/html');
        ?>
        <div class="leave-details">
            <h3>Leave Application #<?php echo $application['id']; ?></h3>
            
            <div class="detail-grid">
                <div class="detail-row">
                    <span class="label">Teacher:</span>
                    <span><?php echo htmlspecialchars($application['name']); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Teacher ID:</span>
                    <span><?php echo htmlspecialchars($application['teacher_id']); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Email:</span>
                    <span><?php echo htmlspecialchars($application['email']); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Leave Type:</span>
                    <span><?php echo htmlspecialchars($application['leave_type']); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Dates:</span>
                    <span>
                        <?php echo date('M d, Y', strtotime($application['leave_start_date'])); ?> 
                        to 
                        <?php echo date('M d, Y', strtotime($application['leave_end_date'])); ?>
                        (<?php echo $total_days; ?> days)
                    </span>
                </div>
                <div class="detail-row">
                    <span class="label">Status:</span>
                    <span class="status-badge <?php echo strtolower(str_replace(' ', '-', $application['status'])); ?>">
                        <?php echo $application['status']; ?>
                    </span>
                </div>
                <div class="detail-row full-width">
                    <span class="label">Description:</span>
                    <div class="description-box">
                        <?php echo nl2br(htmlspecialchars($application['description'])); ?>
                    </div>
                </div>
                <?php if (!empty($application['substitute_details'])): ?>
                <div class="detail-row full-width">
                    <span class="label">Substitute Arrangements:</span>
                    <div class="description-box">
                        <?php echo nl2br(htmlspecialchars($application['substitute_details'])); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        
    } catch(PDOException $e) {
        header('HTTP/1.1 500 Internal Server Error');
        echo "Error loading application details: " . $e->getMessage();
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    echo "Invalid request";
}
?>
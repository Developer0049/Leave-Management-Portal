<?php
session_start();

// Redirect to login if the user is not logged in or is not an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}
if (!empty($_GET['start_date']) && !empty($_GET['end_date'])) {
    $query .= " AND created_at BETWEEN ? AND ?";
    $params[] = $_GET['start_date'];
    $params[] = $_GET['end_date'];
}
include 'includes/db.php';

// Get search and filter parameters
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';

// Build the query based on filters
$query = "SELECT * FROM leave_applications WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (teacher_id LIKE ? OR name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($status_filter)) {
    $query .= " AND status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY created_at DESC";

// Fetch filtered leave applications
$stmt = $conn->prepare($query);
$stmt->execute($params);
$applications = $stmt->fetchAll();

// Include FPDF library
require('fpdf/fpdf.php');

// Create a new PDF instance
$pdf = new FPDF();
$pdf->AddPage();

// Set font for the title
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Filtered Leave Applications', 0, 1, 'C');

// Set font for the content
$pdf->SetFont('Arial', '', 12);

// Add leave details to the PDF
foreach ($applications as $leave) {
    $pdf->Cell(0, 10, 'Leave ID: ' . $leave['id'], 0, 1);
    $pdf->Cell(0, 10, 'Teacher ID: ' . $leave['teacher_id'], 0, 1);
    $pdf->Cell(0, 10, 'Name: ' . $leave['name'], 0, 1);
    $pdf->Cell(0, 10, 'Email: ' . $leave['email'], 0, 1);
    $pdf->Cell(0, 10, 'Leave Type: ' . $leave['leave_type'], 0, 1);
    $pdf->Cell(0, 10, 'Start Date: ' . $leave['leave_start_date'], 0, 1);
    $pdf->Cell(0, 10, 'End Date: ' . $leave['leave_end_date'], 0, 1);
    $pdf->Cell(0, 10, 'Description: ' . $leave['description'], 0, 1);
    $pdf->Cell(0, 10, 'Status: ' . $leave['status'], 0, 1);
    $pdf->Cell(0, 10, 'Date Submitted: ' . $leave['created_at'], 0, 1);
    $pdf->Ln(10); // Add some space between entries
}

// Output the PDF
$pdf->Output('D', 'filtered_leave_applications.pdf');
?>
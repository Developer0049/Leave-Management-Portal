<?php
header('Content-Type: application/json');
require_once 'includes/db.php'; // Include your database connection if needed

// Get the requested year (default to current year)
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Major National Holidays (fixed dates)
$nationalHolidays = [
    $year.'-01-26' => 'Republic Day',
    $year.'-08-15' => 'Independence Day',
    $year.'-10-02' => 'Gandhi Jayanti',
    $year.'-12-25' => 'Christmas'
];

// Regional Holidays (Bangalore/Karnataka specific)
$regionalHolidays = [
    // Ugadi (Hindu New Year - based on lunar calendar, approximate dates)
    $year.'-04-09' => 'Ugadi',
    
    // Karnataka Rajyotsava (State Formation Day)
    $year.'-11-01' => 'Karnataka Rajyotsava',
    
    // Ganesh Chaturthi (approximate dates)
    $year.'-09-07' => 'Ganesh Chaturthi',
    
    // Dasara (Vijayadashami)
    $year.'-10-23' => 'Dasara',
    
    // Deepavali (approximate dates)
    $year.'-11-12' => 'Deepavali',
    
    // Makara Sankranti
    $year.'-01-14' => 'Makar Sankranti',
    
    // Maha Shivaratri
    $year.'-03-08' => 'Maha Shivaratri'
];

// Optional: Fetch holidays from database if you have them stored
/*
$dbHolidays = [];
try {
    $stmt = $conn->prepare("SELECT holiday_date, holiday_name FROM holidays WHERE YEAR(holiday_date) = ?");
    $stmt->execute([$year]);
    $dbHolidays = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    // Log error if needed
}
*/

// Combine all holidays
$allHolidays = array_merge($nationalHolidays, $regionalHolidays /*, $dbHolidays */);

// Format for FullCalendar
$calendarEvents = [];
foreach ($allHolidays as $date => $name) {
    $calendarEvents[] = [
        'title' => $name,
        'start' => $date,
        'color' => '#6c757d', // Gray color for holidays
        'display' => 'background',
        'extendedProps' => [
            'isHoliday' => true,
            'type' => 'holiday'
        ]
    ];
}

// Add weekend highlighting (optional)
/*
$startDate = new DateTime("$year-01-01");
$endDate = new DateTime("$year-12-31");
$interval = new DateInterval('P1D');
$period = new DatePeriod($startDate, $interval, $endDate);

foreach ($period as $date) {
    if ($date->format('N') >= 6) { // Saturday (6) and Sunday (7)
        $calendarEvents[] = [
            'start' => $date->format('Y-m-d'),
            'display' => 'background',
            'color' => '#f8f9fa',
            'extendedProps' => [
                'isWeekend' => true
            ]
        ];
    }
}
*/

// Return JSON response
echo json_encode($calendarEvents);

// Error handling if JSON encoding fails
if (json_last_error() !== JSON_ERROR_NONE) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'Failed to generate holiday data']);
}
?>
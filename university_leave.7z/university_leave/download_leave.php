<?php
session_start();

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include 'includes/db.php';

// Check if leave ID is provided
if (!isset($_GET['id'])) {
    die("Leave ID not provided.");
}

$leave_id = $_GET['id'];

// Fetch leave application details
$stmt = $conn->prepare("SELECT * FROM leave_applications WHERE id = ?");
$stmt->execute([$leave_id]);
$leave = $stmt->fetch();

if (!$leave) {
    die("Leave application not found.");
}

// Include FPDF library
require('fpdf/fpdf.php');

// Create a new PDF instance
$pdf = new FPDF();
$pdf->AddPage();

// Set font for the title
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Leave Application Details', 0, 1, 'C');

// Set font for the content
$pdf->SetFont('Arial', '', 12);

// Add leave details to the PDF
$pdf->Cell(0, 10, 'Leave ID: ' . $leave['id'], 0, 1);
$pdf->Cell(0, 10, 'Teacher ID: ' . $leave['teacher_id'], 0, 1);
$pdf->Cell(0, 10, 'Name: ' . $leave['name'], 0, 1);
$pdf->Cell(0, 10, 'Email: ' . $leave['email'], 0, 1);
$pdf->Cell(0, 10, 'Leave Type: ' . $leave['leave_type'], 0, 1);
$pdf->Cell(0, 10, 'Start Date: ' . $leave['leave_start_date'], 0, 1);
$pdf->Cell(0, 10, 'End Date: ' . $leave['leave_end_date'], 0, 1);
$pdf->Cell(0, 10, 'Description: ' . $leave['description'], 0, 1);
$pdf->Cell(0, 10, 'Status: ' . $leave['status'], 0, 1);
$pdf->Cell(0, 10, 'Date Submitted: ' . $leave['created_at'], 0, 1);

// Output the PDF
$pdf->Output('D', 'leave_application_' . $leave['id'] . '.pdf');
?>